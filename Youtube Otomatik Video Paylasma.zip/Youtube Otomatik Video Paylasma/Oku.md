

**YOUTUBE VİDEO BOT**

**.env** İçerisindeki bölümleri kendinize göre düzenleyiniz.

**CALLBAC**  Website urlnizi yani projenizin urlsini yazınız

**HOOKUR**  Mesajın gönderileceği kanalın webhook urlsini buraya ekleyiniz

**POR**  8000 veya 8080 portunu kullanabilirsini.

**CHI**  Youtube kanalınız ID'sini girinizg

**Loz 'Bey** Tarafından Paylaşılmıştır. %100 Alıntıdır Kodlama Şahsıma Ait Değildir.